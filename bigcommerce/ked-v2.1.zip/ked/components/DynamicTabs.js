// AUTHOR: Kenneth Utting, Kutting Edge Designs
//
// Tabs on the product pages are normally hardwired into the theme.
// Dynamic tabs allow you to store the content of tabs in separate files,
// which has the advantage that they can be managed by content specialists without requiring theme updates.

/*
Dynamic tabs are similar to dropzones, in that they allow you to use a page's HTML property to provide content,
but move it to a specific location on the page. In this case, your content will appear in a tab.
This functionality is supported on both gear and event product pages. 
 
There are two forms for the html. The first is designed for a tab you want to drop in using a page's HTML.
The second is designed for a tab that gets its input from an external file. 
 
 <div class="ked-tab" data-ked-position="{{ POSITION }}" data-ked-title="{{ TITLE }}"> 
     {{ CONTENT }} 
 </div> 
 
 <div class="ked-tab" data-ked-content="{{ CONTENT URL }}"> 
 </div> 
 
In the second case, the html in the external file must start with the position and title information: 
 <input id="ked-tab-data" type="hidden" data-ked-position="{{ POSITION }}" data-ked-title="{{ TITLE }}" /> 
 {{ CONTENT }} 
 
POSITION is a number, and determines where the dynamic tab will be put. For example,
a POSITION of 3 means that the tab will be placed after the third tab. 
Use a position of 0 to place the tab ahead of the first tab. 
If the position attribute is omitted, the tab will be placed after all the other tabs. 
Note that if you add multiple dynamic tabs, the POSITION needs to account for the previously inserted dynamic tabs. 
 
TITLE is the text you want for the title of the tab. For example, "Our Guarantee". 
 
CONTENT is any arbitrary HTML and is displayed when the user clicks on the tab's title. 
For content stored in a file, you may want to put it on the BigCommerce DAV server, in the content/tabs folder.

To use Dynamic Tabs, modify /assets/js/PageManager.js.
	At the top of the file, with the other import lines, add the following line:
		import DynamicTabs from "./theme/ked/components/DynamicTabs";

	In the before() method, add the following lines:
		//  Move dynamic dropzone content to tabs
		(new DynamicTabs()).loadTabs();
Additionally, you will need to be sure that the PageManager's before() method is invoked on the
particular page you are trying to use it on. Tabs are generally used on Product pages,
so in /assets/js/theme/product.js
	If there is a before() method, and it contains a line that says:
		next();
	this must be changed to:
		super.before(next);

Additionally, you must also add this to your SCSS files, for example in assets/scss/theme.scss:
	.ked-tab { display: none }
This keeps the dynamic tab content hidden while the JavaScript gets the content and moves it to the desired location.
/* */

import RemoteContent from "./RemoteContent";

export default class DynamicTabs extends RemoteContent {
	constructor() {
		super("ked-dynamic-tabs", 5 * 60);

		this.tabIndex = 0;
		window.kuttingedgedesigns = window.kuttingedgedesigns || {};
		window.kuttingedgedesigns.dynamicTabs = "KDU 2018031200";
	}

	loadTabs () {
		var self = this;

		$(".ked-tab").each(function () {
			// Decide if this is a local or remote tab content
			const $this = $(this);
			const tabContentURL = $this.data("ked-content");

			if (!!tabContentURL)
				self.loadRemoteTab(tabContentURL);
			else
				self.loadLocalTab($this);

			$this.remove();             		 	// remove the html from its temporary location
		});
	}

	loadLocalTab ($source) {
		let insertPosition = $source.data("ked-position");
		const tabTitle = $source.data("ked-title");
		const tabContent = $source.html();

		this.insertTab(insertPosition, tabTitle, tabContent);
	}

	loadRemoteTab (tabContentURL) {
		this.getRemoteContent(tabContentURL, (tabContent) => {
			const $dataElement = $(tabContent).filter("#ked-tab-data");
			if ($dataElement.length <= 0) {
				console.warn("DynamicTabs.loadRemoteTab: No data element in downloaded tab for " + tabContentURL);
				return;
			}
			console.log("Dynamic Tab content downloaded from " + tabContentURL);

			let insertPosition = $dataElement.data("ked-position");
			const tabTitle = $dataElement.data("ked-title");

			this.insertTab(insertPosition, tabTitle, tabContent);
		});
	}

	insertTab (insertPosition, tabTitle, tabContent) {
		console.log("DynamicTabs.insertTab(" + insertPosition + ", " + tabTitle + ", " + tabContent + ")");
		const tabId =  "ked-tabid_" + this.tabIndex++;
		const chevron = "<svg class='icon icon-chevron-down'><use xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='#icon-chevron-down'></use></svg>";

		// If there are no existing tabs, probably this page doesn't support tabs, so abort
		const numberOfExistingTabs = $("section.product-tabs ul.tabs li.tab-title").length;
		if (numberOfExistingTabs <= 0) {
			console.log("DynamicTabs.insertTab: not inserting dynamic tab because there are no existing tabs");
			return;
		}

		// Determine how & where to insert the tab
		insertPosition = !!insertPosition ? parseInt(insertPosition) : 1000;
		let insertBefore = true;
		if (insertPosition >= numberOfExistingTabs) {
			insertPosition = numberOfExistingTabs - 1;
			insertBefore = false;
		}

		// Find the elements we'll insert the tab next to
		const $targetElements = {};
		$targetElements.titleLi = $("section.product-tabs ul.tabs li.tab-title").eq(insertPosition);
		$targetElements.titleSpan = $("section.product-tabs div.tabs-content span.accordion-title").eq(insertPosition);
		$targetElements.contentPanel = $("section.product-tabs div.tabs-content div.tab-content-panel").eq(insertPosition);

		// Insert the new tab, either before or after the target elements
		if (insertBefore) {
			$targetElements.titleLi.before("<li class='tab-title'><a href='#" + tabId + "'>" + tabTitle + "</a></li>");
			$targetElements.titleSpan.before("<span class='accordion-title'><a href='#" + tabId + "' data-scroll='#" + tabId + "'>" + chevron + tabTitle + "</a></span>");
			$targetElements.titleSpan.before("<div class='tab-content-panel' id='" + tabId + "'>" + tabContent + "</div>");
			console.log("DynamicTabs.insertTab: inserted tab before. %o", $targetElements);
		} else {
			$targetElements.titleLi.after("<li class='tab-title'><a href='#" + tabId + "'>" + tabTitle + "</a></li>");
			$targetElements.contentPanel.after("<div class='tab-content-panel' id='" + tabId + "'>" + tabContent + "</div>");
			$targetElements.contentPanel.after("<span class='accordion-title'><a href='#" + tabId + "' data-scroll='#" + tabId + "'>" + chevron + tabTitle + "</a></span>");
			console.log("DynamicTabs.insertTab: inserted tab after. %o", $targetElements);
		}
	}
}

// AUTHOR: Kenneth Utting, Kutting Edge Designs