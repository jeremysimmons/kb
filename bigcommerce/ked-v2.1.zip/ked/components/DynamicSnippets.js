// AUTHOR: Kenneth Utting, Kutting Edge Designs
//
// One of the limitations of the BigCommerce WYSIWYG HTML editor is that it doesn't permit stylesheets in the HTML.
// Snippets allow you to create a file that includes both HTML and stylesheets.
// Snippets also provide a way to create content in one location and then include it on multiple pages.

/*
Snippets are similar to Dynamic tabs, in that they allow you to use a page's HTML property to
provide content, but pull it from a separate file. 
 
Here is the format of the HTML that needs to placed on each page that uses the snippet:
 
 <div class="ked-snippet" data-ked-content="{{ CONTENT URL }}">
  <em>Loading...</em>
 </div> 
 
The external file can contain any arbitrary HTML and CSS and is displayed in the spot on the page where the ked-snippet div is located. 
You may want to put the file on the BigCommerce DAV server, in the content/snippets folder.

To use Dynamic Tabs, modify /assets/js/PageManager.js.
	At the top of the file, with the other import lines, add the following line:
		import DynamicSnippets from "./theme/goruck/components/DynamicSnippets";

	In the before() method, add the following lines:
		//	Insert snippets into page
		(new DynamicSnippets()).loadSnippets();
Additionally, you will need to be sure that the PageManager's before() method is invoked on the
particular page you are trying to use Snippets on. For example, if you are trying to use them on Product pages,
then in /assets/js/theme/product.js
	If there is a before() method, and it contains a line that says:
		next();
	this must be changed to:
		super.before(next);
*/

import RemoteContent from "./RemoteContent";

export default class DynamicSnippets extends RemoteContent {
	constructor() {
		super("ked-dynamic-snippets", 5 * 60);
	}

	loadSnippets () {
		var self = this;

		$(".ked-snippet").each(function () {
			// Decide if this is a local or remote tab content
			const $this = $(this);
			const snippetContentURL = $this.data("ked-content");

			if (!!snippetContentURL)
				self.loadSnippet($this, snippetContentURL);
			else
				console.error("DynamicSnippets.loadSnippets: snippet has no data-ked-content attribute");
		});
	}

	loadSnippet ($rootElement, snippetContentURL) {
		this.getRemoteContent(snippetContentURL, (snippetContent) => {
			console.log("DynamicSnippets.loadSnippet: putting " + snippetContentURL + " snippet into page");
			$rootElement.after(snippetContent);
			$rootElement.remove();             		 	// remove the html from its temporary location
		});
	}
}

// AUTHOR: Kenneth Utting, Kutting Edge Designs